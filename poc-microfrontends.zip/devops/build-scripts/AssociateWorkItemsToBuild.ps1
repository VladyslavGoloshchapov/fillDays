param(
    [String] $BuildNumber = "$env:BUILD_BUILDNUMBER"
)

[String] $CollectionUrl = "$env:SYSTEM_TEAMFOUNDATIONCOLLECTIONURI"
Write-Host "Collection Url:" $CollectionUrl

[String] $BuildUrl = "$env:BUILD_BUILDURI"
Write-Host "Build Url:" $BuildUrl

[String] $project = "$env:SYSTEM_TEAMPROJECT"
Write-Host "Project:" $project

[String] $BuildId = "$env:BUILD_BUILDID"
Write-Host "Build Id:" $BuildId

Write-Host "Build Number:" $BuildNumber

Try
{
	$WorkItemAssociatedUrl = $CollectionUrl + $project + "/_apis/build/builds/" + $BuildId + "/workitems?api-version=2.0"
	Write-Host "Work Item Associated Url:" $WorkItemAssociatedUrl

	$Response = Invoke-RestMethod -Uri $WorkItemAssociatedUrl -ContentType "application/json" -Method GET -UseDefaultCredentials
	$WorkItemCount = $Response.count
	$WorkItemUrlArray = $Response.value

	Write-Host "Work Item Count:" $WorkItemCount

	for($i = 0; $i -lt $WorkItemCount ; $i++)
	{
		$WorkitemUpdateBody = '
		[
			{
			"op": "add",
			"path": "/fields/Microsoft.VSTS.Build.IntegrationBuild",
			"value": "' + $BuildNumber + '"
			}
		]'

		$WorkitemUpdateUrl = $WorkItemUrlArray[$i].url + "?api-version=2.0"
		
		Write-Host "Work Item Update Url:" $WorkitemUpdateUrl
		Write-Host "Work Item Update Body:" $WorkitemUpdateBody

		Invoke-RestMethod -Uri $WorkitemUpdateUrl -Body $WorkitemUpdateBody -ContentType "application/json-patch+json" -Method Patch -UseDefaultCredentials
	}
}
Catch
{
	Write-Host $_.Exception.Message
	Write-Host $_.Exception.ItemName
	Break
}