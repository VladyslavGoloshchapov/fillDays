# Introduction 
This is a collection of apps which are supposed to prove that micro front ends architecture is nice option
for future Orbus development

Please read README in each separate project.