import "./set-public-path";
import React from "react";
import ReactDOM from "react-dom";
import singleSpaReact from "single-spa-react";
import UserDetails from "./userDetailsRoot.component";

const lifecycles = singleSpaReact({
  React,
  ReactDOM,
  rootComponent: UserDetails,
  errorBoundary(err, info, props) {
    // Customize the root error boundary for your microfrontend here.
    return null;
  },
});

export const { bootstrap, mount, unmount } = lifecycles;
export const name = '@orbus/userDetails';
export const version = '2.1.1';
export const modulesRequirements = {
  '@orbus/users': '*',
  '@orbus/roles': '*',
};
