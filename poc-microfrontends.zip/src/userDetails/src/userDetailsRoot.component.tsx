import { Customizer, DefaultButton, initializeIcons, IPersonaSharedProps, Persona, PersonaSize } from '@fluentui/react';
import { FluentCustomizations } from '@uifabric/fluent-theme';
import React, { useEffect, useState } from "react";
import { singleSpaWindow } from './types';
import { users } from "./users";

initializeIcons();

interface IUserDetailsProps {
  userId: number|null;
}

export default function UserDetails(props: IUserDetailsProps) {
  const [selectedUserId, setSelectedUserId] = useState<number>(props.userId);
  useEffect(() => {
    function handleUserSelection(event: CustomEvent) {
      setSelectedUserId(event.detail.userId);
    }
    window.addEventListener('userSelected', handleUserSelection);
    return () => {
      window.removeEventListener('userSelected', handleUserSelection)
    };
  });

  if (selectedUserId === null) {
    return null;
  }
  
  const rolesModuleAvailable = singleSpaWindow.SingleSPA.configuredApps['@orbus/roles'] !== undefined;
  const selectedUser = users.find((user) => user.id === selectedUserId);

  const persona: IPersonaSharedProps = {
    imageUrl: selectedUser.photo,
    imageInitials: selectedUser.name,
    text: selectedUser.name,
    tertiaryText: selectedUser.phone,
    optionalText: selectedUser.email,
    presence: selectedUser.presence,
  };
  
  if (rolesModuleAvailable) {
    persona.secondaryText = selectedUser.role;
  }

  return (
    <Customizer {...FluentCustomizations}>
      {selectedUserId === null ? null : (
        <>
          <Persona
            {...persona}
            size={PersonaSize.size120}
          />
          {rolesModuleAvailable && <DefaultButton text="Change role" onClick={() => {alert('now change the role')}} />
}
        </>
      )}
    </Customizer>
  );
}
