export type version = string;
export interface IApp extends System.Module {
  name: string;
  version: version;
  modulesRequirements: {
    [name: string]: string;
  }
}

export interface IConfiguredApp {
  name: string;
  activeWhen: string[] | ((location: Location) => boolean);
  domElement: HTMLElement;
  urlParams?: (location: Location) => {};
}

export interface ISingleSPAWindow {
  SingleSPA: {
    loadedApps: {[name: string]: IApp};
    configuredApps: {[name: string]: IConfiguredApp}
  }
};

export const singleSpaWindow = (window as any as ISingleSPAWindow);