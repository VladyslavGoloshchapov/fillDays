import { PersonaPresence } from '@fluentui/react';

export const users = [
  {
    "id": 1,
    "name": "user1",
    "role": "admin",
    "email": "user1@gmail.com",
    "phone": "1-770-736-8031 x56442",
    "photo": "https://toppng.com/uploads/preview/login-icons-user-flat-icon-115534363917nmr24mjcm.png",
    presence: PersonaPresence.away
  },
  {
    "id": 2,
    "name": "user2",
    "role": "qa&dev",
    "email": "user2@gmail.com",
    "phone": "1-770-736-8031 x56442",
    "photo": "https://w0.pngwave.com/png/1017/542/computer-icons-female-user-icon-design-female-png-clip-art.png",
    presence: PersonaPresence.blocked
  },
  {
    "id": 3,
    "name": "user3",
    "role": "contentViewer",
    "email": "user3@gmail.com",
    "phone": "1-770-736-8031 x56442",
    "photo": "https://toppng.com/uploads/preview/login-icons-user-flat-icon-115534363917nmr24mjcm.png",
    presence: PersonaPresence.busy
  },
  {
    "id": 4,
    "name": "user4",
    "role": "admin",
    "email": "user4@gmail.com",
    "phone": "1-770-736-8031 x56442",
    "photo": "https://png.pngtree.com/png-vector/20190307/ourlarge/pngtree-vector-user-management-icon-png-image_779417.jpg",
    presence: PersonaPresence.dnd
  },
  {
    "id": 5,
    "name": "user5",
    "role": "qa&dev",
    "email": "user5@gmail.com",
    "phone": "1-770-736-8031 x56442",
    "photo": "https://toppng.com/uploads/preview/login-icons-user-flat-icon-115534363917nmr24mjcm.png",
    presence: PersonaPresence.offline
  },
  {
    "id": 6,
    "name": "user6",
    "role": "contentViewer",
    "email": "user6@gmail.com",
    "phone": "1-770-736-8031 x56442",
    "photo": "https://icons.iconarchive.com/icons/visualpharm/must-have/256/User-icon.png",
    presence: PersonaPresence.online
  },
  {
    "id": 7,
    "name": "user7",
    "role": "contentViewer",
    "email": "user7@gmail.com",
    "phone": "1-770-736-8031 x56442",
    "photo": "https://www.iconfinder.com/data/icons/rcons-user-action/512/user-512.png",
    presence: PersonaPresence.blocked
  },
  {
    "id": 8,
    "name": "user8",
    "role": "qa&dev",
    "email": "user8@gmail.com",
    "phone": "1-770-736-8031 x56442",
    "photo": "https://w0.pngwave.com/png/1017/542/computer-icons-female-user-icon-design-female-png-clip-art.png",
    presence: PersonaPresence.away
  },
]