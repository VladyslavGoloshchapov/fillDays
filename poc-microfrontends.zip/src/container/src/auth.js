// Config object to be passed to Msal on creation.
// For a full list of msal.js configuration parameters, 
// visit https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/configuration.md
const msalConfig = {
  auth: {
      clientId: "1f9d9f7d-fee0-4a69-9f52-f640bcdfb58c",
      authority: "https://login.microsoftonline.com/common",
      redirectUri: "http://localhost:9000",
  },
  cache: {
      cacheLocation: "sessionStorage", // This configures where your cache will be stored
  }
};

// Add here the scopes that you would like the user to consent during sign-in
const loginRequest = {
  scopes: ["User.Read"]
};

const myMSALObj = new Msal.UserAgentApplication(msalConfig);
let accessToken;

// Register Callbacks for Redirect flow
myMSALObj.handleRedirectCallback(authRedirectCallBack);

function authRedirectCallBack(error, response) {
  if (error) {
      console.log(error);
  } else {
      if (response.tokenType === "id_token") {
          console.log("id_token acquired at: " + new Date().toString()); 
      } else if (response.tokenType === "access_token") {
        console.log("access_token acquired at: " + new Date().toString());
        accessToken = response.accessToken;

        try {
          callMSGraph(graphConfig.graphMailEndpoint, accessToken, updateUI);
        } catch(err) {
          console.log(err)
        } finally {
        }
      } else {
          console.log("token type is:" + response.tokenType);
      }
  }
}
export function getUsername() {
  if (myMSALObj.getAccount()) {
    return myMSALObj.getAccount().userName;
  }
}

export function signIn() {
  myMSALObj.loginRedirect(loginRequest);
}

export function signOut() {
  myMSALObj.logout();
}