import semverSatisfies from 'semver/functions/satisfies';
import { registerApplication, start } from "single-spa";
import { getUsername, signIn, signOut } from "./auth";
import { loadApp } from "./mfeLoader";
import { IApp, singleSpaWindow } from "./types";

const usersAppName = "@orbus/users";
const userDetailsAppName = "@orbus/userDetails";
const rolesAppName = "@orbus/roles";

singleSpaWindow.SingleSPA = {
  loadedApps: {},
  configuredApps: {
    [usersAppName]: {
      activeWhen: (location: Location) => !location.pathname.includes('userDetails'),
      domElement: document.getElementById("users"),
    },
    [userDetailsAppName]: {
      activeWhen: ["/", '/userDetails'],
      domElement: document.getElementById("userDetails"),
      urlParams: (location: Location) => {
        const path = location.pathname;
        let userId = null;
        if (path.includes('/userDetails')) {
          userId = parseInt(path.substr(path.lastIndexOf('/') + 1, path.length));
        }
        return { userId };
      },
    },
    [rolesAppName]: {
      activeWhen: (location: Location) => !location.pathname.includes('userDetails'),
      domElement: document.getElementById("roles"),
    },
  }
};

const loadingAppPromises: Promise<IApp>[] = [];

function loadAppWithPromise(name: string) {
  const promise = loadApp(name);
  loadingAppPromises.push(promise);
  return promise;
}

Object.keys(singleSpaWindow.SingleSPA.configuredApps).forEach((appName) => {
  const app = singleSpaWindow.SingleSPA.configuredApps[appName];
  registerApplication({
    name: appName,
    app: loadAppWithPromise.bind(null, appName),
    activeWhen: app.activeWhen,
    customProps: (name, location) => {
      let params = app.urlParams ? app.urlParams(location) : {};

      return { domElement: app.domElement, ...params };
    }
  });
});

setTimeout(() => {
  Promise.all(loadingAppPromises).then((modules) => {
    modules.forEach((module) => {
      const moduleName = module.name;
      console.info(`Checking module requirements of ${moduleName}`);
      Object.keys(module.modulesRequirements).forEach((requiredModuleName) => {
        const requiredVersion = module.modulesRequirements[requiredModuleName];
        const requiredModule = modules.find(m => m.name === requiredModuleName);

        if (requiredModule === undefined) {
          console.error(`   Module ${requiredModuleName} required by ${moduleName} is missing`);
          return;
        }

        const actualModuleVersion = requiredModule.version;
        if (semverSatisfies(actualModuleVersion, requiredVersion)) {
          console.info(`    Module ${requiredModuleName} with version ${actualModuleVersion} required by ${moduleName} satisfies version requirement ${requiredVersion}`);
        } else {
          console.error(`   Module ${requiredModuleName} with version ${actualModuleVersion} required by ${moduleName} doesn't satisfy version requirement ${requiredVersion}`);
        }
      });
    });
  });
}, 0);

function startAppWithAuthentication() {
  window.document.querySelector('.signIn').addEventListener('click', signIn);
  const username = getUsername();
  if (username) {
    window.document.querySelector('.loggedUser').classList.remove('d-none');
    window.document.querySelector('.username').textContent = username;
    start({
      urlRerouteOnly: true,
    });
    window.document.querySelector('.signOut').addEventListener('click', signOut);
  } else {
    window.document.querySelector('.signIn').classList.remove('d-none');
  }
}

startAppWithAuthentication();
