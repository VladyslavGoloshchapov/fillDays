import { IApp, singleSpaWindow } from "./types";

export async function loadApp(name: string) {
  try {
    const app = await System.import<IApp>(name);
    singleSpaWindow.SingleSPA.loadedApps[name] = app;
    return app;
  } catch (e) {
    console.error(`Error loading app ${name} ${e}`);
  }
}