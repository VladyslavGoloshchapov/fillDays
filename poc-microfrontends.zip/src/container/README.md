# Introduction 
This is a container app for micro front ends architecture.

# Getting Started
1.	Installation process
   npm i
2.	Software dependencies
3.	Latest releases
4.	API references

# Build and Test
run in dev mode
  - npm run start
  - open browser "http://localhost:9000/"
build
  - npm run build