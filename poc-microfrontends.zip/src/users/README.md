# Introduction 
This is a micro front end to display user app

# Getting Started
1.	Installation process
   npm i
2.	Software dependencies
3.	Latest releases
4.	API references

# Build and Test
1. Run 'npm start -- --port 8500'
2. Go to http://single-spa-playground.org/playground/instant-test?name=@orbus/users&url=8500 to see it working!

build
  - npm run build