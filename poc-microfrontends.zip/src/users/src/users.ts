export const users = [
  {
    "id": 1,
    "name": "user1",
    "role": "admin"
  },
  {
    "id": 2,
    "name": "user2",
    "role": "qa&dev"
  },
  {
    "id": 3,
    "name": "user3",
    "role": "contentViewer"
  },
  {
    "id": 4,
    "name": "user4",
    "role": "admin"
  },
  {
    "id": 5,
    "name": "user5",
    "role": "qa&dev"
  },
  {
    "id": 6,
    "name": "user6",
    "role": "contentViewer"
  },
  {
    "id": 7,
    "name": "user7",
    "role": "contentViewer"
  },
  {
    "id": 8,
    "name": "user8",
    "role": "qa&dev"
  },
]