import { Customizer, DetailsList, IColumn, initializeIcons, Link, SelectionMode, buildColumns, omit } from '@fluentui/react';
import { FluentCustomizations } from '@uifabric/fluent-theme';
import React, { useEffect, useState } from "react";
import { singleSpaWindow } from './types';
import { users } from "./users";

initializeIcons(/* optional base url */);

export default function Root() {
  const [selectedRole, setSelectedRole] = useState<string>(null);
  useEffect(() => {
    function handleRoleSelection(event: CustomEvent) {
      setSelectedRole(event.detail.roleName);
    }
    window.addEventListener('roleSelected', handleRoleSelection);
    return () => {
      window.removeEventListener('roleSelected', handleRoleSelection)
    };
  }, []);

  let effectiveUsers = users;
  if (selectedRole !== null) {
    effectiveUsers = users.filter(user => user.role === selectedRole);
  }

  let effectiveUsersWithLink = effectiveUsers.map(user => (
    {
      ...user,
      url: <Link
        href='#'
        onClick={(e) => {
          e.preventDefault();
          history.pushState({}, '', `userDetails/${user.id}`)}
        }>
        {user.name}
      </Link>})
  );

  if (singleSpaWindow.SingleSPA.configuredApps['@orbus/roles'] === undefined) {
    effectiveUsersWithLink = effectiveUsersWithLink.map(user => omit(user, ['role']));
  }

  const columns = buildColumns(effectiveUsersWithLink);
  columns[0].maxWidth = 100;
  columns[1].maxWidth = 100;
  columns[2].maxWidth = 100;

  return (
    <Customizer {...FluentCustomizations}>
      <DetailsList
        items={effectiveUsersWithLink}
        columns={columns}
        selectionMode={SelectionMode.single}
        onActiveItemChanged={user => window.dispatchEvent(new CustomEvent('userSelected', {detail: {userId: user.id}}))}
      />
    </Customizer>
  );
}
