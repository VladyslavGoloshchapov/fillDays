import { Component } from '@angular/core';
import {roles} from './roles';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  roles = roles;

  public onRoleSelection(roleName: string) {
    window.dispatchEvent(new CustomEvent('roleSelected', {detail: {roleName}}));
  }
}
