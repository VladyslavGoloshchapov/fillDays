export const roles = [
  {
    name: 'admin',
    description: 'Super users'
  },
  {
    name: 'qa&dev',
    description: 'QAs and Developers'
  },
  {
    name: 'contentViewer',
    description: 'Can only read content'
  }
];
